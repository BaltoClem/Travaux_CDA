create view v_globalcde1 as
select `papyrus`.`ligcom`.`codart`                                      AS `codart`,
       sum(`papyrus`.`ligcom`.`qtecde`)                                 AS `Qtetot`,
       sum((`papyrus`.`ligcom`.`qtecde` * `papyrus`.`ligcom`.`priuni`)) AS `Prixtot`
from `papyrus`.`ligcom`
group by `papyrus`.`ligcom`.`codart`;

