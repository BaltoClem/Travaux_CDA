create definer = root@localhost view v_ventesl100 as
select `papyrus`.`vente`.`codart` AS `codart`,
       `papyrus`.`vente`.`numfou` AS `numfou`,
       `papyrus`.`vente`.`delliv` AS `delliv`,
       `papyrus`.`vente`.`qte1`   AS `qte1`,
       `papyrus`.`vente`.`prix1`  AS `prix1`,
       `papyrus`.`vente`.`qte2`   AS `qte2`,
       `papyrus`.`vente`.`prix2`  AS `prix2`,
       `papyrus`.`vente`.`qte3`   AS `qte3`,
       `papyrus`.`vente`.`prix3`  AS `prix3`
from `papyrus`.`vente`
where (`papyrus`.`vente`.`codart` = 'I100');

