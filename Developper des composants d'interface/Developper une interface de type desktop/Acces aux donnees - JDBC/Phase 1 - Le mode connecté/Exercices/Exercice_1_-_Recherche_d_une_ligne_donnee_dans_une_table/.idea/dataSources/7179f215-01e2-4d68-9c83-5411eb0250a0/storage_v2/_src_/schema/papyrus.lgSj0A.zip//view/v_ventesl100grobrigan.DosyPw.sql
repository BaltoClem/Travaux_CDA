create definer = root@localhost view v_ventesl100grobrigan as
select `v_ventesl100`.`codart` AS `codart`,
       `v_ventesl100`.`numfou` AS `numfou`,
       `v_ventesl100`.`delliv` AS `delliv`,
       `v_ventesl100`.`qte1`   AS `qte1`,
       `v_ventesl100`.`prix1`  AS `prix1`,
       `v_ventesl100`.`qte2`   AS `qte2`,
       `v_ventesl100`.`prix2`  AS `prix2`,
       `v_ventesl100`.`qte3`   AS `qte3`,
       `v_ventesl100`.`prix3`  AS `prix3`
from `papyrus`.`v_ventesl100`
where (`v_ventesl100`.`numfou` = 120);

