create
    definer = root@localhost procedure CA_Fournisseur(IN four varchar(50), IN annee int)
BEGIN
    SELECT numfou, SUM(qtecde * priuni *1.20) AS "Chiffre d'affaire annuel"
    FROM ligcom, entcom
    WHERE entcom.numcom = ligcom.numcom
    AND four = numfou
    AND annee = YEAR(datcom)
    GROUP BY numfou;
END;

