create definer = root@localhost trigger prod_maj
    after update
    on produit
    for each row
BEGIN

    DECLARE stockale INT;
    DECLARE stockphy INT;
    DECLARE codarticle CHAR(4);
    DECLARE datecom DATETIME;
    DECLARE qteacom INT;
    SET codarticle = NEW.codart;
    SET stockale = (SELECT stkale FROM produit WHERE codart = codarticle);
    SET stockphy = (SELECT stkphy FROM produit WHERE codart = codarticle);
    SET qteacom = (SELECT qte FROM articles_a_commander WHERE codart = codarticle);
    SET datecom = (SELECT datecomm FROM articles_a_commander WHERE codart = codarticle);
    IF stockphy < stockale AND qteacom IS NULL THEN
    INSERT INTO articles_a_commander(codart, datecomm, qte)
    VALUES ( NEW.codart, NOW(), stockale - stockphy);
    ELSEIF qteacom IS NOT NULL THEN
    UPDATE articles_a_commander 
    SET qte=((stockale - stockphy) - qteacom)
    WHERE codart = codarticle;
    END IF;
    END;

