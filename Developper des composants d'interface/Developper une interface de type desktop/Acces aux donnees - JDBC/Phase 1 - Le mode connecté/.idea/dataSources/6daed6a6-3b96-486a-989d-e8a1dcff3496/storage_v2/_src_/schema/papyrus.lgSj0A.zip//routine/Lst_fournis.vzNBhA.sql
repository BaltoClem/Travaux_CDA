create
    definer = root@localhost procedure Lst_fournis()
BEGIN
    SELECT numfou, COUNT(numcom) AS 'Nombre de commandes'
    FROM entcom
    GROUP BY numfou;
END;

