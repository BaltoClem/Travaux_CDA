create view v_chahotres as
select `hotel`.`chambre`.`cha_numero` AS `Numéro de chambre`,
       `hotel`.`hotel`.`hot_nom`      AS `Numéro de l'hôtel`,
       `hotel`.`station`.`sta_nom`    AS `Nom de la station`
from ((`hotel`.`chambre` join `hotel`.`hotel`)
         join `hotel`.`station`)
where ((`hotel`.`chambre`.`cha_hot_id` = `hotel`.`hotel`.`hot_id`) and
       (`hotel`.`hotel`.`hot_sta_id` = `hotel`.`station`.`sta_id`))
order by `hotel`.`chambre`.`cha_numero`;

