create definer = root@localhost trigger modif_reservation
    after update
    on reservation
    for each row
BEGIN
    SIGNAL SQLSTATE '40000' SET MESSAGE_TEXT = 'Un problème est survenu. Interdiction de modifier !';
    END;

