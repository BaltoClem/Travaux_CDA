create definer = root@localhost trigger insert_reservation2
    after insert
    on reservation
    for each row
BEGIN
    DECLARE clireserv INT; 
    DECLARE numcli INT;
    SET numcli = NEW.res_cli_id;
    SET clireserv = (SELECT COUNT(res_id) FROM reservation WHERE res_cli_id = numcli);
    IF clireserv > 3 THEN
        SIGNAL SQLSTATE '40000' SET MESSAGE_TEXT = 'Trop de réservations de la part 
        du client!';
    END IF;
    END;

