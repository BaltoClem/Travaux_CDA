create view v_chahot as
select `hotel`.`chambre`.`cha_numero` AS `Numéro de chambre`, `hotel`.`hotel`.`hot_nom` AS `Nom d'hôtel`
from (`hotel`.`chambre`
         join `hotel`.`hotel` on ((`hotel`.`chambre`.`cha_hot_id` = `hotel`.`hotel`.`hot_id`)))
order by `hotel`.`chambre`.`cha_numero`;

