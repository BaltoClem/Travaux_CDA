create
    definer = root@localhost procedure ajoutClient(IN nom varchar(50), IN prenom varchar(50), IN ville varchar(50))
BEGIN
   INSERT INTO client (cli_nom, cli_prenom, cli_ville) VALUES (nom, prenom, ville);
END;

