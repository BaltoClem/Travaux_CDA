create view v_rescli as
select `hotel`.`reservation`.`res_id` AS `Numéro de réservation`, `hotel`.`client`.`cli_nom` AS `Nom du client`
from (`hotel`.`reservation`
         join `hotel`.`client` on ((`hotel`.`reservation`.`res_cli_id` = `hotel`.`client`.`cli_id`)))
order by `hotel`.`reservation`.`res_id`;

