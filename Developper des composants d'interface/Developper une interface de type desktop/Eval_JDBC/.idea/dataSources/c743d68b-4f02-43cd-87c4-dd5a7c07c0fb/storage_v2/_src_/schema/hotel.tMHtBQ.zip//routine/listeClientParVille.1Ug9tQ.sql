create
    definer = root@localhost procedure listeClientParVille(IN ville varchar(50))
BEGIN
   SELECT cli_id, cli_nom, cli_prenom, cli_ville 
   FROM client
   WHERE cli_ville = ville;
END;

