create definer = root@localhost trigger insert_reservation
    after insert
    on reservation
    for each row
BEGIN
    DECLARE reserv INT;
    SET reserv = (SELECT COUNT(cha_hot_id)
    FROM reservation, chambre, hotel
    WHERE res_cha_id = cha_id AND cha_hot_id = hot_id);
    IF reserv > 10 THEN
        SIGNAL SQLSTATE '40000' SET MESSAGE_TEXT = 'Capacité insuffisante !';
    END IF;
    END;

