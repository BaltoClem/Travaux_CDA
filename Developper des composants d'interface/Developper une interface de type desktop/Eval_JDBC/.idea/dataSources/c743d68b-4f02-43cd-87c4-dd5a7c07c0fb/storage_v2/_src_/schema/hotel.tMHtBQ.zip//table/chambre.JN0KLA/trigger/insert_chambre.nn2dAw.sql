create definer = root@localhost trigger insert_chambre
    after insert
    on chambre
    for each row
BEGIN
        DECLARE capacite INT;
        DECLARE numcham INT;
        SET numcham = NEW.cha_hot_id;
        SET capacite = (SELECT SUM(cha_capacite)
        FROM chambre, hotel
        WHERE cha_hot_id = hot_id AND cha_hot_id = numcham);
        IF capacite > 50 THEN
            SIGNAL SQLSTATE '40000' SET MESSAGE_TEXT = 'Capacité des chambres insuffisante !';
        END IF;
    END;

