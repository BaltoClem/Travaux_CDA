create view v_resclihot as
select `hotel`.`reservation`.`res_id` AS `Numéro de réservation`,
       `hotel`.`client`.`cli_nom`     AS `Nom du client`,
       `hotel`.`hotel`.`hot_nom`      AS `Nom de l'hôtel`
from (((`hotel`.`reservation` join `hotel`.`client`) join `hotel`.`chambre`)
         join `hotel`.`hotel`)
where ((`hotel`.`reservation`.`res_cli_id` = `hotel`.`client`.`cli_id`) and
       (`hotel`.`reservation`.`res_cha_id` = `hotel`.`chambre`.`cha_id`) and
       (`hotel`.`chambre`.`cha_hot_id` = `hotel`.`hotel`.`hot_id`))
order by `hotel`.`reservation`.`res_id`;

