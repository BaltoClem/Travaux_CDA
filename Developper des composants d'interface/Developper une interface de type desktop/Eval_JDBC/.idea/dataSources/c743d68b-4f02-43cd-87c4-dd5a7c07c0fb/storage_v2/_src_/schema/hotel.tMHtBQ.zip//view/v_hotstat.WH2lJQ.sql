create view v_hotstat as
select `hotel`.`hotel`.`hot_nom` AS `Nom d'hôtel`, `hotel`.`station`.`sta_nom` AS `Nom de station`
from (`hotel`.`hotel`
         join `hotel`.`station` on ((`hotel`.`hotel`.`hot_sta_id` = `hotel`.`station`.`sta_id`)))
order by `hotel`.`hotel`.`hot_nom`;

